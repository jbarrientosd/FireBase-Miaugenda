package ust.etetech.secondtry;

public class Mascota {

    private String id;
    private String nombre;
    private String raza;
    private String fecha_de_nacimiento;
    private int edad;
    private String sexo;
    private String vacunas;
    private String esterilizacion;
    private int peso;

    public Mascota() {
    }

    public Mascota(String id, String nombre, String raza, String fecha_de_nacimiento, int edad, String sexo, String vacunas, String esterilizacion, int peso) {
        this.id = id;
        this.nombre = nombre;
        this.raza = raza;
        this.fecha_de_nacimiento = fecha_de_nacimiento;
        this.edad = edad;
        this.sexo = sexo;
        this.vacunas = vacunas;
        this.esterilizacion = esterilizacion;
        this.peso = peso;
    }

    public Mascota(String nombre, String raza, String fecha_de_nacimiento, int edad, String sexo, String vacunas, String esterilizacion, int peso) {
        this.nombre = nombre;
        this.raza = raza;
        this.fecha_de_nacimiento = fecha_de_nacimiento;
        this.edad = edad;
        this.sexo = sexo;
        this.vacunas = vacunas;
        this.esterilizacion = esterilizacion;
        this.peso = peso;
    }

    public Mascota(String nombre, String raza, int edad) {
        this.nombre = nombre;
        this.raza = raza;
        this.edad = edad;
    }

    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getFecha_de_nacimiento() {
        return fecha_de_nacimiento;
    }

    public void setFecha_de_nacimiento(String fecha_de_nacimiento) {
        this.fecha_de_nacimiento = fecha_de_nacimiento;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getVacunas() {
        return vacunas;
    }

    public void setVacunas(String vacunas) {
        this.vacunas = vacunas;
    }

    public String getEsterilizacion() {
        return esterilizacion;
    }

    public void setEsterilizacion(String esterilizacion) {
        this.esterilizacion = esterilizacion;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }
}
