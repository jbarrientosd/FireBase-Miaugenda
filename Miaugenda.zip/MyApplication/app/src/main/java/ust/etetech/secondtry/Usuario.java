package ust.etetech.secondtry;

public class Usuario {

    private int id;
    private String nombre;
    private int edad;
    private String fecha_de_nacimiento;
    private String correo;
    private String contrasena;

    public Usuario(int id, String nombre, int edad, String fecha_de_nacimiento, String correo, String contrasena) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
        this.fecha_de_nacimiento = fecha_de_nacimiento;
        this.correo = correo;
        this.contrasena = contrasena;
    }

    public Usuario(String nombre, int edad, String fecha_de_nacimiento, String correo, String contrasena) {
        this.nombre = nombre;
        this.edad = edad;
        this.fecha_de_nacimiento = fecha_de_nacimiento;
        this.correo = correo;
        this.contrasena = contrasena;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getFecha_de_nacimiento() {
        return fecha_de_nacimiento;
    }

    public void setFecha_de_nacimiento(String fecha_de_nacimiento) {
        this.fecha_de_nacimiento = fecha_de_nacimiento;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }
}
