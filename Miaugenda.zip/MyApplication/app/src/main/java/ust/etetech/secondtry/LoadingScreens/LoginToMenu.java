package ust.etetech.secondtry.LoadingScreens;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import ust.etetech.secondtry.Miaulogin;
import ust.etetech.secondtry.R;
import ust.etetech.secondtry.miaucarga;
import ust.etetech.secondtry.miaumenu;

public class LoginToMenu extends AppCompatActivity {

    private int tiempocarga = 1500;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login_to_menu);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(LoginToMenu.this, miaumenu.class);
                startActivity(intent);
                finish();
            }
        }, tiempocarga);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}