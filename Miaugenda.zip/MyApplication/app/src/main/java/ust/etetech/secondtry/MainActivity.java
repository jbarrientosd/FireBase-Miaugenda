package ust.etetech.secondtry;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import ust.etetech.secondtry.DB.DatabaseManager;
import ust.etetech.secondtry.DB.DbHelper;

public class MainActivity extends AppCompatActivity {

    private EditText et1, et2, et3, et4, et5;
    private Button b1, b2;
    private int tiempocarga = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        et3 = findViewById(R.id.et3);
        et4 = findViewById(R.id.et4);
        et5 = findViewById(R.id.et5);
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nombre = et1.getText().toString();
                String edad = et2.getText().toString();
                String fecha_de_nacimiento = et3.getText().toString();
                String correo  = et4.getText().toString();
                String contrasena = et5.getText().toString();

                DbHelper dbHelper = new DbHelper(MainActivity.this);
                SQLiteDatabase db = dbHelper.getWritableDatabase();

                DatabaseManager dbManager = new DatabaseManager(getApplicationContext());

                if (db != null) {
                    dbManager.insertUsuario(nombre, Integer.parseInt(edad), fecha_de_nacimiento, correo, contrasena);
                    Toast.makeText(MainActivity.this, "Se registró correctamente", Toast.LENGTH_LONG).show();
                    et1.setText("");
                    et2.setText("");
                    et3.setText("");
                    et4.setText("");
                    et5.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Ocurrio un error", Toast.LENGTH_LONG).show();
                }
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(MainActivity.this, Miaulogin.class);
                        startActivity(intent);
                        finish();
                    }
                }, tiempocarga);

            }
        });

    }
}