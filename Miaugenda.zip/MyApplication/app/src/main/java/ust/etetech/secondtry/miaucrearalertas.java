package ust.etetech.secondtry;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;

import java.sql.Time;
import java.util.UUID;

import ust.etetech.secondtry.DB.DatabaseManager;
import ust.etetech.secondtry.DB.DbHelper;

public class miaucrearalertas extends AppCompatActivity {

    private TextView txtHora, txtFecha;
    private EditText etcr1;
    private Button bcr1, bcr2, btnFecha, btnHora;
    private int tiempocarga = 0;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_miaucrearalertas);

        etcr1 = findViewById(R.id.etcr1);
        btnFecha = findViewById(R.id.btnFecha);
        btnHora = findViewById(R.id.btnHora);
        bcr1 = findViewById(R.id.bcr1);
        bcr2 = findViewById(R.id.bcr2);
        txtHora = findViewById(R.id.txtHora);
        txtFecha = findViewById(R.id.txtFecha);


        FirebaseApp.initializeApp(this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnFecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialogDate();
            }
        });

        btnHora.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialogTime();
            }
        });

        bcr1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = UUID.randomUUID().toString();
                String nombre = etcr1.getText().toString();
                String fecha = txtFecha.getText().toString();
                String hora = txtHora.getText().toString();

                if (nombre.isEmpty() || fecha.isEmpty() || hora.isEmpty()) {
                    Toast.makeText(miaucrearalertas.this, "Debe rellenar todos los campos", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(miaucrearalertas.this, "Se añadio su alerta", Toast.LENGTH_LONG).show();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Alerta alerta = new Alerta(id, nombre, fecha, hora);
                            databaseReference.child("Alerta").child(id).setValue(alerta);
                            Intent intent = new Intent(miaucrearalertas.this, miaualertas.class);
                            startActivity(intent);
                        }
                    }, tiempocarga);
                }

                // ------------------ SQLlite Methods ------------------ \\
//                DbHelper dbHelper = new DbHelper(miaucrearalertas.this);
//                SQLiteDatabase db = dbHelper.getWritableDatabase();
//                DatabaseManager dbManager = new DatabaseManager(getApplicationContext());
//                dbManager.insertAlerta(nombre, fecha, hora);
//
//
//                if (db != null) {
//                    dbManager.insertAlerta(nombre, fecha, hora);
//                    Toast.makeText(miaucrearalertas.this, "Se registró correctamente.", Toast.LENGTH_LONG).show();
//                    etcr1.setText("");
//                    etcr2.setText("");
//                    etcr3.setText("");
//                } else {
//                    Toast.makeText(miaucrearalertas.this, "Ocurrio un error.", Toast.LENGTH_LONG).show();
//                    etcr1.setText("");
//                    etcr2.setText("");
//                    etcr3.setText("");
//                }
            }
        });

        bcr2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(miaucrearalertas.this, miaualertas.class);
                        startActivity(intent);
                    }
                }, tiempocarga);
            }
        });


    }

    private void openDialogDate() {

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, R.style.DialogTheme, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                String strDay = String.valueOf(day);
                String strMonth = String.valueOf(month);
                String strYear = String.valueOf(year);

                if (month <= 9) {
                    strMonth = "0"+month;
                }
                if (day <= 9) {
                    strDay = "0"+day;
                }

                txtFecha.setText(strDay+"/"+strMonth+"/"+strYear);

            }
        }, 2024, 11 , 3);
        datePickerDialog.show();
    }

    private void openDialogTime() {

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, R.style.DialogTheme, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int horas, int minutos) {
                String strHoras = String.valueOf(horas);
                String strMinutos = String.valueOf(minutos);

                if(horas <= 9) {
                    strHoras = "0"+horas;
                }

                if(minutos <= 9) {
                    strMinutos = "0"+minutos;
                }

                txtHora.setText(strHoras+":"+strMinutos);

            }
        }, 15, 00, true);
        timePickerDialog.show();

    }

}