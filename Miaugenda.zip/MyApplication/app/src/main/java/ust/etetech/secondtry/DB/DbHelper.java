package ust.etetech.secondtry.DB;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "maiugenda2.db";
    private static final int DATABASE_VERSION = 1;
    public static final String TABLE_USUARIOS = "usuario";
    public static final String TABLE_MASCOTAS = "mascota";
    public static final String TABLE_ALERTA = "alerta";

    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_USUARIOS + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nombre TEXT NOT NULL," +
                "edad INT NOT NULL," +
                "fecha_de_nacimiento TEXT NOT NULL," +
                "correo TEXT NOT NULL," +
                "contraseña TEXT)");
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_MASCOTAS + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nombre TEXT NOT NULL," +
                "raza TEXT NOT NULL," +
                "fecha_de_nacimiento TEXT NOT NULL," +
                "edad INT NOT NULL," +
                "sexo TEXT," +
                "vacunas TEXT," +
                "esterilizacion TEXT)");
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_ALERTA + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nombre TEXT NOT NULL," +
                "fecha TEXT NOT NULL," +
                "hora TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE " + TABLE_USUARIOS);
        sqLiteDatabase.execSQL("DROP TABLE " + TABLE_MASCOTAS);
        sqLiteDatabase.execSQL("DROP TABLE " + TABLE_ALERTA);
        onCreate(sqLiteDatabase);
    }

    public void onCreateGatos(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_MASCOTAS + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nombre TEXT NOT NULL," +
                "raza TEXT NOT NULL," +
                "fecha_de_nacimiento TEXT NOT NULL," +
                "edad INT NOT NULL," +
                "sexo TEXT," +
                "vacunas TEXT," +
                "lugar TEXT)");
    }

}
