package ust.etetech.secondtry;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class sobremiAdapter extends RecyclerView.Adapter<sobremiAdapter.MyViewHolder> {
    private List<Usuario> sobremiList;


    public sobremiAdapter(List<Usuario> sobremiList) {
        this.sobremiList = sobremiList;
    }

    @NonNull
    @Override
    public sobremiAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent , int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_sobremi, parent, false);
        return new sobremiAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull sobremiAdapter.MyViewHolder holder, int position) {
        Usuario usuario = sobremiList.get(position);
        holder.tvnombre.setText(usuario.getNombre());
        holder.tvedad.setText(String.valueOf(usuario.getEdad()));
        holder.tvfechadenacimiento.setText(usuario.getFecha_de_nacimiento());
        holder.tvcorreo.setText(usuario.getCorreo());
    }

    @Override
    public int getItemCount() {
        return sobremiList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvnombre;
        TextView tvedad;
        TextView tvfechadenacimiento;
        TextView tvcorreo;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvnombre = itemView.findViewById(R.id.tvnombre);
            tvedad = itemView.findViewById(R.id.tvedad);
            tvfechadenacimiento = itemView.findViewById(R.id.tvfechadenacimiento);
            tvcorreo = itemView.findViewById(R.id.tvcorreo);
        }
    }
}
