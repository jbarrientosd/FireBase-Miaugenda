package ust.etetech.secondtry;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class miaualertasAdapter extends RecyclerView.Adapter<miaualertasAdapter.MyViewHolder> {
    private List<Alerta> alertasList;
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Alerta");


    public miaualertasAdapter(List<Alerta> alertasList) {
        this.alertasList = alertasList;
    }

    @NonNull
    @Override
    public miaualertasAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent , int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_alertas, parent, false);
        return new miaualertasAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull miaualertasAdapter.MyViewHolder holder, int position) {
        Alerta alerta = alertasList.get(position);
        holder.tvnombrealarma.setText(alerta.getNombre());
        holder.tvfechaalarma.setText(alerta.getFecha());
        holder.tvhoraalarma.setText(alerta.getHora());
        holder.btnEliminar.setOnClickListener(v -> {
            alertasList.remove(position);
            notifyItemRemoved(position);
            databaseReference.child(alerta.getId()).removeValue();
        });
    }

    @Override
    public int getItemCount() {
        return alertasList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvnombrealarma;
        TextView tvfechaalarma;
        TextView tvhoraalarma;
        ImageButton btnEliminar;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvnombrealarma = itemView.findViewById(R.id.tvnombrealarma);
            tvfechaalarma = itemView.findViewById(R.id.tvfechaalarma);
            tvhoraalarma = itemView.findViewById(R.id.tvhoraalarma);
            btnEliminar = itemView.findViewById(R.id.btnEliminar);
        }
    }
}
