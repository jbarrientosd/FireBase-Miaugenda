package ust.etetech.secondtry;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import ust.etetech.secondtry.LoadingScreens.LoginToMenu;

public class miaumenu extends AppCompatActivity {

    private ImageButton ibm1, ibm2, ibm3, ibm4;
    private int tiempocarga = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_miaumenu);

        ibm1 = findViewById(R.id.ibm1);
        ibm2 = findViewById(R.id.ibm2);
        ibm3 = findViewById(R.id.ibm3);
        ibm4 = findViewById(R.id.ibm4);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ibm1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(miaumenu.this, miaumisgatos.class);
                        startActivity(intent);
                        finish();
                    }
                }, tiempocarga);
            }
        });

        ibm2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(miaumenu.this, miaualertas.class);
                        startActivity(intent);
                        finish();
                    }
                }, tiempocarga);
            }
        });

        ibm3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(miaumenu.this, miausobremi.class);
                        startActivity(intent);
                    }
                }, tiempocarga);
            }
        });

        ibm4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(miaumenu.this, "Disponible proximamente", Toast.LENGTH_LONG).show();
            }
        });


    }
}