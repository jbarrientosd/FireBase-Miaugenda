package ust.etetech.secondtry;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.InternalHelpers;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import ust.etetech.secondtry.DB.DatabaseManager;
import ust.etetech.secondtry.DB.DbHelper;

public class miaualertas extends AppCompatActivity {

    private ImageButton imbta1;
    private Button bta1;
    private RecyclerView RValertas;
    private int tiempocarga = 0;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    private List<Alerta> fbAlertaList = new ArrayList<Alerta>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_miaualertas);

        imbta1 = findViewById(R.id.imbta1);
        bta1 = findViewById(R.id.bta1);
        RValertas = findViewById(R.id.RValertas);

        FirebaseApp.initializeApp(this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();

        RecyclerView recyclerView = RValertas;
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // ------------------- SQLite ------------------- \\
        // DatabaseManager dbManager = new DatabaseManager(getApplicationContext());
        // List<Alerta> alertasList = dbManager.getAllAlertas();
        // miaualertasAdapter adapter = new miaualertasAdapter(alertasList);
        // recyclerView.setAdapter(adapter);

        // Firebase GetAllData
        databaseReference.child("Alerta").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                fbAlertaList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Alerta a = snapshot.getValue(Alerta.class);
                    fbAlertaList.add(a);

                    List<Alerta> alertasList = fbAlertaList;

                    miaualertasAdapter adapter = new miaualertasAdapter(alertasList);
                    recyclerView.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        imbta1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(miaualertas.this, miaucrearalertas.class);
                        startActivity(intent);
                        finish();
                    }
                }, tiempocarga);
            }
        });

        bta1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(miaualertas.this, miaumenu.class);
                        startActivity(intent);
                        finish();
                    }
                }, tiempocarga);
            }
        });

    }
}