package ust.etetech.secondtry;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import ust.etetech.secondtry.DB.DatabaseManager;

public class miaumisgatos extends AppCompatActivity {

    private RecyclerView RVgatos;
    private ImageButton ibmg1;
    private Button btmg1;
    private int tiempocarga = 0;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    private List<Mascota> fbMascotaList = new ArrayList<Mascota>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_miaumisgatos);

        RVgatos = findViewById(R.id.RVgatos);
        ibmg1 = findViewById(R.id.ibmg1);
        btmg1 = findViewById(R.id.btmg1);

        FirebaseApp.initializeApp(this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();

        RecyclerView recyclerView = RVgatos;
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

//        DatabaseManager dbManager = new DatabaseManager(getApplicationContext());
//        List<Mascota> gatosList = dbManager.getAllMascotas();
//        miaumisgatosAdapter adapter = new miaumisgatosAdapter(gatosList);
//        recyclerView.setAdapter(adapter);

        databaseReference.child("Mascota").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                fbMascotaList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Mascota mascota = snapshot.getValue(Mascota.class);
                    fbMascotaList.add(mascota);

                    List<Mascota> gatosList = fbMascotaList;

                    miaumisgatosAdapter adapter = new miaumisgatosAdapter(gatosList);
                    recyclerView.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        ibmg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(miaumisgatos.this, infogato.class);
                        startActivity(intent);
                        finish();
                    }
                }, tiempocarga);
            }
        });

        btmg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(miaumisgatos.this, miaumenu.class);
                        startActivity(intent);
                        finish();
                    }
                }, tiempocarga);
            }
        });

    }
}