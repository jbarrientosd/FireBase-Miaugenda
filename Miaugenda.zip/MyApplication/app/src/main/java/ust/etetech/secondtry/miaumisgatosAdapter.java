package ust.etetech.secondtry;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class miaumisgatosAdapter extends RecyclerView.Adapter<miaumisgatosAdapter.MyViewHolder> {
    private List<Mascota> gatosList;


    public miaumisgatosAdapter(List<Mascota> gatosList) {
        this.gatosList = gatosList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent , int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_gatos, parent, false);
        return new MyViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Mascota mascota = gatosList.get(position);
        holder.tvgnombre.setText(mascota.getNombre());
        holder.tvgedad.setText("Edad: " + String.valueOf(mascota.getEdad()) + " años");
        holder.tvgnacimiento.setText("F. Nacimiento: " + mascota.getFecha_de_nacimiento());
        holder.tvgraza.setText("Raza: " + mascota.getRaza());
        holder.tvgvacunas.setText("¿Tiene sus vacunas?: " + mascota.getVacunas());
        holder.tvgesterilizado.setText("¿Está esterilizado?: " + mascota.getEsterilizacion());
        holder.tvgpeso.setText("Peso: " + String.valueOf(mascota.getPeso()) + "KG");
        holder.tvgsexo.setText("Sexo: " + mascota.getSexo());
    }


    @Override
    public int getItemCount() {
        return gatosList.size();
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvgnombre;
        TextView tvgedad;
        TextView tvgnacimiento;
        TextView tvgraza;
        TextView tvgvacunas;
        TextView tvgesterilizado;
        TextView tvgpeso;
        TextView tvgsexo;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvgnombre = itemView.findViewById(R.id.tvgnombre);
            tvgedad = itemView.findViewById(R.id.tvgedad);
            tvgnacimiento = itemView.findViewById(R.id.tvgnacimiento);
            tvgraza = itemView.findViewById(R.id.tvgraza);
            tvgvacunas = itemView.findViewById(R.id.tvgvacunas);
            tvgesterilizado = itemView.findViewById(R.id.tvgesterilizado);
            tvgpeso = itemView.findViewById(R.id.tvgpeso);
            tvgsexo = itemView.findViewById(R.id.tvgsexo);
        }
    }

}