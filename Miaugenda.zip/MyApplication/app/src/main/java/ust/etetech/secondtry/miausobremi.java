package ust.etetech.secondtry;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class miausobremi extends AppCompatActivity {

    private Button btsm1;
    private RecyclerView RVsobremi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_miausobremi);

        btsm1 = findViewById(R.id.btsm1);
        RVsobremi = findViewById(R.id.RVsobremi);

        RecyclerView recyclerView = RVsobremi;
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<Usuario> sobremiList = new ArrayList<>();
        sobremiList.add(new Usuario("Vania", 22, "No me acordaba perdón", "vania@miaugenda.maiu", "12346"));

        sobremiAdapter adapter = new sobremiAdapter(sobremiList);
        recyclerView.setAdapter(adapter);

        btsm1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }
}