package ust.etetech.secondtry;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import ust.etetech.secondtry.DB.DatabaseManager;
import ust.etetech.secondtry.LoadingScreens.LoginToMenu;

public class Miaulogin extends AppCompatActivity {

    private EditText et01, et02;
    private Button b01, b02, b03;
    private int tiempocarga = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_miaulogin);

        et01 = findViewById(R.id.et01);
        et02 = findViewById(R.id.et02);
        b01 = findViewById(R.id.b01);
        b02 = findViewById(R.id.b02);
        b03 = findViewById(R.id.b03);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        b01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseManager dbManager = new DatabaseManager(getApplicationContext());

                String user = et01.getText().toString();
                String password = et02.getText().toString();

                int total_users = dbManager.getAllUsuarios().size();
                for (int i = 0; i < total_users; i++) {
                    if (dbManager.getAllUsuarios().get(i).getCorreo().equals(user) && dbManager.getAllUsuarios().get(i).getContrasena().equals(password)) {

                    } else {
                        Toast.makeText(Miaulogin.this, "Datos incorrectos", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

        b02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(Miaulogin.this, LoginToMenu.class);
                        startActivity(intent);
                        finish();
                    }
                }, tiempocarga);
            }
        });

        b03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(Miaulogin.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }, tiempocarga);
            }
        });

    }
}