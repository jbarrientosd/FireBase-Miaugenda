package ust.etetech.secondtry.DB;

import static ust.etetech.secondtry.DB.DbHelper.TABLE_ALERTA;
import static ust.etetech.secondtry.DB.DbHelper.TABLE_USUARIOS;
import static ust.etetech.secondtry.DB.DbHelper.TABLE_MASCOTAS;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import ust.etetech.secondtry.Alerta;
import ust.etetech.secondtry.Mascota;
import ust.etetech.secondtry.Usuario;

public class DatabaseManager {

    private DbHelper dbHelper;

    public DatabaseManager(Context context) {
        dbHelper = new DbHelper(context);
    }

    // AÑADIR UN ELEMENTO
    public void insertUsuario(String nombre, int edad, String fecha_de_nacimiento, String correo, String contrasena) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nombre", nombre);
        values.put("edad", edad);
        values.put("fecha_de_nacimiento", fecha_de_nacimiento);
        values.put("correo", correo);
        values.put("contrasena", contrasena);
        db.insert(TABLE_USUARIOS, null, values);
        db.close();
    }

    // TRAER TODOS LOS DATOS DEL SQLITE
    public ArrayList<Usuario> getAllUsuarios() {
        ArrayList<Usuario> UsuariosList = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USUARIOS , null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String nombre = cursor.getString(1);
                int edad = cursor.getInt(2);
                String fecha_de_nacimiento = cursor.getString(3);
                String correo = cursor.getString(4);
                String contrasena = cursor.getString(5);
                Usuario usuario = new Usuario(id, nombre, edad, fecha_de_nacimiento, correo, contrasena);
                UsuariosList.add(usuario);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return UsuariosList;
    }

    // Actualizar registro
    public void updateUsuario(Usuario usuario) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nombre", usuario.getNombre());
        values.put("edad", usuario.getEdad());
        values.put("fecha_de_nacimiento", usuario.getFecha_de_nacimiento());
        values.put("correo", usuario.getCorreo());
        values.put("contrasena", usuario.getContrasena());
        db.update(TABLE_USUARIOS, values, "id = ?", new String[]{String.valueOf(usuario.getId())});
        db.close();
    }

    // Eliminar tarea
    public void deleteUsuario(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(TABLE_USUARIOS, "id = ?", new String[]{String.valueOf(id)});
        db.close();
    }

    // Buscar registro por id
    public Usuario getUsuarioById(int id) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USUARIOS + " WHERE id = ? ", new String[]{String.valueOf(id)});

        if (cursor != null && cursor.moveToFirst()) {
            String nombre = cursor.getString(1);
            int edad = cursor.getInt(2);
            String fecha_de_nacimiento = cursor.getString(3);
            String correo = cursor.getString(4);
            String contrasena = cursor.getString(5);
            Usuario usuario = new Usuario(id, nombre, edad, fecha_de_nacimiento, correo, contrasena);
            cursor.close();
            db.close();
            return usuario;
        }
        assert cursor != null;
        cursor.close();
        db.close();
        return null;
    }

    // ---------------------------------------------------------

    public void insertMascota(String nombre, String raza, String fecha_de_nacimiento, int edad, String sexo, String vacunas, String esterilizacion, int peso) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nombre", nombre);
        values.put("raza", raza);
        values.put("fecha_de_nacimiento", fecha_de_nacimiento);
        values.put("edad", edad);
        values.put("sexo", sexo);
        values.put("vacunas", vacunas);
        values.put("esterilizacion", esterilizacion);
        values.put("peso", peso);
        db.insert(TABLE_MASCOTAS, null, values);
        db.close();
    }

    public ArrayList<Mascota> getAllMascotas() {
        ArrayList<Mascota> MascotasList = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_MASCOTAS , null);

        if (cursor.moveToFirst()) {
            do {
                String id = cursor.getString(0);
                String nombre = cursor.getString(1);
                String raza = cursor.getString(2);
                String fecha_de_nacimiento = cursor.getString(3);
                int edad = cursor.getInt(4);
                String sexo = cursor.getString(5);
                String vacunas = cursor.getString(6);
                String esterilizacion = cursor.getString(7);
                int peso = cursor.getInt(8);
                Mascota mascota = new Mascota(id, nombre, raza, fecha_de_nacimiento, edad, sexo, vacunas, esterilizacion, peso);
                MascotasList.add(mascota);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return MascotasList;
    }

    public void updateMascota(Mascota mascota) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("id", mascota.getId());
        values.put("nombre", mascota.getNombre());
        values.put("raza", mascota.getEdad());
        values.put("fecha_de_nacimiento", mascota.getFecha_de_nacimiento());
        values.put("edad", mascota.getEdad());
        values.put("sexo", mascota.getSexo());
        values.put("vacunas", mascota.getVacunas());
        values.put("esterilizacion", mascota.getEsterilizacion());
        db.update(TABLE_MASCOTAS, values, "id = ?", new String[]{String.valueOf(mascota.getId())});
        db.close();
    }

    public void deleteMascota(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(TABLE_MASCOTAS, "id = ?", new String[]{String.valueOf(id)});
        db.close();
    }

    public Mascota getMascotaById(String id) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_MASCOTAS + " WHERE id = ? ", new String[]{String.valueOf(id)});

        if (cursor != null && cursor.moveToFirst()) {
            String nombre = cursor.getString(0);
            String raza = cursor.getString(1);
            String fecha_de_nacimiento = cursor.getString(2);
            int edad = cursor.getInt(3);
            String sexo = cursor.getString(4);
            String vacunas = cursor.getString(5);
            String esterilizacion = cursor.getString(6);
            int peso = cursor.getInt(7);
            Mascota mascota = new Mascota(id, nombre, raza, fecha_de_nacimiento, edad, sexo, vacunas, esterilizacion, peso);
            cursor.close();
            db.close();
            return mascota;
        }
        assert cursor != null;
        cursor.close();
        db.close();
        return null;
    }

    // ---------------------------------------------------------

    public void insertAlerta(String nombre, String fecha, String hora) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nombre", nombre);
        values.put("fecha", fecha);
        values.put("hora", hora);
        db.insert(TABLE_ALERTA, null, values);
        db.close();
    }

    public ArrayList<Alerta> getAllAlertas() {
        ArrayList<Alerta> AlertasList = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_ALERTA , null);

        if (cursor.moveToFirst()) {
            do {
                String id = cursor.getString(0);
                String nombre = cursor.getString(1);
                String fecha = cursor.getString(2);
                String hora = cursor.getString(3);
                Alerta alerta = new Alerta(id, nombre, fecha, hora);
                AlertasList.add(alerta);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return AlertasList;
    }

}
