package ust.etetech.secondtry;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.UUID;

import ust.etetech.secondtry.DB.DatabaseManager;
import ust.etetech.secondtry.DB.DbHelper;

public class infogato extends AppCompatActivity {

    private EditText etrg1, etrg2, etrg3, etrg4, editTextNumber3;
    private Spinner sprg1, sprg2;
    private Switch srg1;
    private Button btrg1, btrg2;
    private int tiempocarga = 0;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_infogato);

        etrg1 = findViewById(R.id.etrg1);
        etrg2 = findViewById(R.id.etrg2);
        etrg3 = findViewById(R.id.etrg3);
        etrg4 = findViewById(R.id.etrg4);
        sprg1 = findViewById(R.id.sprg1);
        sprg2 = findViewById(R.id.sprg2);
        srg1 = findViewById(R.id.srg1);
        btrg1 = findViewById(R.id.btrg1);
        btrg2 = findViewById(R.id.btrg2);
        editTextNumber3 = findViewById(R.id.editTextNumber3);

        FirebaseApp.initializeApp(this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        String[] opciones1 = {"Macho" , "Hembra"};
        String[] opciones2 = {"Si" , "No"};

        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opciones1);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sprg1.setAdapter(adapter1);

        sprg1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
                String sexo = parent.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opciones2);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sprg2.setAdapter(adapter2);

        sprg2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
                String vacuna = parent.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        srg1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    String esterilizacion = "Si";
                } else {
                    String esterilizacion = "No";
                }
            }
        });

        btrg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = UUID.randomUUID().toString();
                String nombre = etrg1.getText().toString();
                String edad = etrg2.getText().toString();
                String fecha_cumpleanos = etrg3.getText().toString();
                String raza = etrg4.getText().toString();
                String sexo = "Macho";
                String vacunas = "Si";
                String esterilizacion = "Si";
                String peso = editTextNumber3.getText().toString();

                if (nombre.isEmpty() || edad.isEmpty() || fecha_cumpleanos.isEmpty() || raza.isEmpty() || peso.isEmpty()) {
                    Toast.makeText(infogato.this, "Debe rellenar todos los campos", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(infogato.this, "Se añadio su mascota", Toast.LENGTH_LONG).show();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Mascota mascota = new Mascota(id, nombre, raza, fecha_cumpleanos, Integer.parseInt(edad), sexo, vacunas, esterilizacion, Integer.parseInt(peso));
                            databaseReference.child("Mascota").child(id).setValue(mascota);
                            Intent intent = new Intent(infogato.this, miaumisgatos.class);
                            startActivity(intent);
                        }
                    }, tiempocarga);
                }


//                DbHelper dbhelper = new DbHelper(infogato.this);
//                SQLiteDatabase db = dbhelper.getWritableDatabase();
//                DatabaseManager dbManager = new DatabaseManager(getApplicationContext());
//
//                if (db != null) {
//                    dbManager.insertMascota(nombre, raza, fecha_cumpleanos, Integer.parseInt(edad), sexo, vacunas, esterilizacion, Integer.parseInt(peso));
//                    Toast.makeText(infogato.this, "Se registró correctamente", Toast.LENGTH_LONG).show();
//                    new Handler().postDelayed(new Runnable() {
//                        @Override
//                        public void run() {
//                            Intent intent = new Intent(infogato.this, miaumisgatos.class);
//                            startActivity(intent);
//                            finish();
//                        }
//                    }, tiempocarga);
//                } else {
//                    Toast.makeText(infogato.this, "Ocurrio un error", Toast.LENGTH_LONG).show();
//                }
            }
        });

        btrg2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(infogato.this, miaumisgatos.class);
                        startActivity(intent);
                        finish();
                    }
                }, tiempocarga);
            }
        });
    }
}